# Clean up and load libraries
rm(list=ls());
library("data.table");

# "/Users/marcio.barros/Desktop/"
basePath <- '/Users/marcio/Dropbox/Fitness_Loc/analises/Marcio';

# Load instance results
dataFilename <- paste(basePath, '/improvement.csv', sep="");
data <- read.table(dataFilename, header=TRUE, sep=',');

# Calculate derived data
data$imp <- 100 * data$diffchars / data$originalchars;
dt <- data.table(data);

# Load instance sizes
sizeFilename <- paste(basePath, '/sizes.csv', sep="");
size <- read.table(sizeFilename, header=TRUE, sep=',');


# ===================================================
# Descriptive analysis over solution quality
# ===================================================

means <- dt[, .(mean = mean(imp)), by=list(alg, lib)];
meanByAlgorithm <- reshape(means, v.names = "mean", idvar = "lib", timevar = "alg", direction = "wide");
print(meanByAlgorithm, digits=2);

medians <- dt[, .(median = median(imp)), by=list(alg, lib)];
medianByAlgorithm <- reshape(medians, v.names = "median", idvar = "lib", timevar = "alg", direction = "wide");
print(medianByAlgorithm, digits=2);

sds <- dt[, .(sd = sd(imp)), by=list(alg, lib)];
sdByAlgorithm <- reshape(sds, v.names = "sd", idvar = "lib", timevar = "alg", direction = "wide");
print(sdByAlgorithm, digits=2);

maxs <- dt[, .(max = max(imp)), by=list(alg, lib)];
maxByAlgorithm <- reshape(maxs, v.names = "max", idvar = "lib", timevar = "alg", direction = "wide");
print(maxByAlgorithm, digits=2);

mins <- dt[, .(min = min(imp)), by=list(alg, lib)];
minByAlgorithm <- reshape(mins, v.names = "min", idvar = "lib", timevar = "alg", direction = "wide");
print(minByAlgorithm, digits=2);


# ===================================================
# Boxplots for solution quality - paper
# ===================================================

boxplotFilename=paste(basePath, '/results/boxplots.pdf', sep="");
pdf(boxplotFilename, width=7, height=3);

par(mfrow=c(3, 7));
par(mar=c(2.1, 1.1, 1.1, 1.1));
par(mgp=c(2.5, 0.75, 0));
par(las=1);

for (lib_ in unique(data$lib)) {
	rdata <- subset(data, data$lib == lib_);
	
	shc <- subset(rdata, data$alg == "SHC")$imp;
	sfahc <- subset(rdata, data$alg == "SFAHC")$imp;
	dfahc <- subset(rdata, data$alg == "DFAHC")$imp;
	
	ymin <- min(rdata$imp) - 0.1;
	ymax <- max(rdata$imp) + 0.1;
	
	boxplot(shc, sfahc, ylim=c(ymin, ymax), main=lib_, names=c("SHC", "SFAHC"), cex.lab=0.6, cex.axis=0.6, cex.main=0.8, cex.sub=0.6);
	abline(h=dfahc, col="Red");
}

dev.off()


# ===================================================
# Boxplots for solution quality - thesis
# ===================================================

boxplotFilename=paste(basePath, '/results/boxplots-thesis.pdf', sep="");
pdf(boxplotFilename, width=6, height=8);

par(mfrow=c(5, 4));
par(mar=c(2.1, 1.1, 1.1, 1.1));
par(mgp=c(2.5, 0.75, 0));
par(las=1);

for (lib_ in unique(data$lib)) {
	rdata <- subset(data, data$lib == lib_);
	
	shc <- subset(rdata, data$alg == "SHC")$imp;
	sfahc <- subset(rdata, data$alg == "SFAHC")$imp;
	dfahc <- subset(rdata, data$alg == "DFAHC")$imp;
	
	ymin <- min(rdata$imp) - 0.1;
	ymax <- max(rdata$imp) + 0.1;
	
	boxplot(shc, sfahc, ylim=c(ymin, ymax), main=lib_, names=c("SHC", "SFAHC"), cex.lab=0.6, cex.axis=0.6, cex.main=0.8, cex.sub=0.6);
	abline(h=dfahc, col="Red");
}

dev.off()


# ===================================================
# Mins and maxs
# ===================================================

# TODO escrever este script ...


# ===================================================
# Analysis
# ===================================================

# SHC x DFACH
instances <- c("UUID", "XML2js");

for (instance_ in instances) {
	shc <- subset(data, data$alg == "SHC" & data$lib == instance_)$imp;
	dfahc <- subset(data, data$alg == "DFAHC" & data$lib == instance_)$imp;
	pValue <- wilcox.test(shc, mu = dfahc)$p.value;
	print(paste("SHC x DFAHC: pValue(", instance_, ") = ", pValue, sep=""));
}

# SFAHC x DFACH
instances <- c("D3-node", "Decimal", "Exectimer", "Express", "jQuery", "Mathjs", "Minimist", "Node-semver", "Tleaf", "UglifyJs2", "UUID");

for (instance_ in instances) {
	sfahc <- subset(data, data$alg == "SFAHC" & data$lib == instance_)$imp;
	dfahc <- subset(data, data$alg == "DFAHC" & data$lib == instance_)$imp;
	pValue <- wilcox.test(sfahc, mu = dfahc)$p.value;
	print(paste("SFAHC x DFAHC: pValue(", instance_, ") = ", pValue, sep=""));
}


# ===================================================
# Analise de correlacao
# ===================================================

cor(meanByAlgorithm$mean.SFAHC, size$loc, method="spearman");
cor(meanByAlgorithm$mean.SFAHC, size$tests, method="spearman");
cor(meanByAlgorithm$mean.SFAHC, size$cov, method="spearman");

cor(medianByAlgorithm$median.DFAHC - medianByAlgorithm$median.SFAHC, size$loc, method="spearman");
cor(medianByAlgorithm$median.DFAHC - medianByAlgorithm$median.SFAHC, size$tests, method="spearman");
cor(medianByAlgorithm$median.DFAHC - medianByAlgorithm$median.SFAHC, size$cov, method="spearman");




# Descriptive analysis over time
#
# idem ao anterior
#times <- dt[, .(mean = min(time)), by=list(alg, Lib)]
#timeByAlgorithm <- reshape(times, v.names = "mean", idvar = "Lib", timevar = "alg", direction = "wide")
#print(timeByAlgorithm)

# Stat analysis comparing RD and HC
#
# teste de normalidade, teste de inferência, tamanho de efeito


